import os
import shutil
import zipfile

# Pasta raiz onde procurar os .swf
PASTA_ORIGEM = r"./"

# Pasta onde os arquivos serão copiados
PASTA_OBJECT = "object"

# Nome do ZIP final
NOME_ZIP = "object.zip"


def criar_pasta_limpa(path):
    if os.path.exists(path):
        shutil.rmtree(path)
    os.makedirs(path)


def copiar_swf():
    criar_pasta_limpa(PASTA_OBJECT)

    index = 1

    for raiz, dirs, arquivos in os.walk(PASTA_ORIGEM):
        # Evita entrar na própria pasta object
        if PASTA_OBJECT in raiz:
            continue

        for arquivo in arquivos:
            if arquivo.lower().endswith(".swf"):
                origem = os.path.join(raiz, arquivo)

                novo_nome = f"{index}.swf"
                destino = os.path.join(PASTA_OBJECT, novo_nome)

                shutil.copy2(origem, destino)

                print(f"[COPIADO] {origem} -> {destino}")

                index += 1

    print(f"\nTotal de arquivos copiados: {index - 1}")


def criar_zip():
    with zipfile.ZipFile(NOME_ZIP, "w", zipfile.ZIP_DEFLATED) as zipf:
        for arquivo in os.listdir(PASTA_OBJECT):
            caminho = os.path.join(PASTA_OBJECT, arquivo)
            zipf.write(caminho, arcname=arquivo)

    print(f"\nZIP criado: {NOME_ZIP}")


if __name__ == "__main__":
    copiar_swf()
    criar_zip()